
/*
 AIWhenConstructedProc.java

*/

public
abstract class AIWhenConstructedProc {

public boolean isWhenConstructedProc() { return true; }

abstract public
void eval( AIFrameSystem inFrameSystem, AIFrame inFrame );

}